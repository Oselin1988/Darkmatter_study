# Restart script for AMR Dark Matter Study
# Run this at the beginning of your next session

from google.colab import drive
import pandas as pd
import os

# Mount Google Drive
drive.mount('/content/drive')

# Navigate to project folder
project_folder = '/content/drive/MyDrive/AMR_Dark_Matter_Study_2026-04-01'
os.chdir(project_folder)
print(f"✅ Working directory: {os.getcwd()}")

# Load data
data_folder = os.path.join(project_folder, '01_Data')
figures_folder = os.path.join(project_folder, '02_Figures')
scripts_folder = os.path.join(project_folder, '03_Scripts')

# Load included papers
if os.path.exists(os.path.join(data_folder, 'included_papers.csv')):
    df = pd.read_csv(os.path.join(data_folder, 'included_papers.csv'))
    print(f"✅ Loaded included_papers.csv: {len(df)} papers")

# Load clone data
if os.path.exists(os.path.join(data_folder, 'clone_mutation_data.csv')):
    clone_df = pd.read_csv(os.path.join(data_folder, 'clone_mutation_data.csv'))
    print(f"✅ Loaded clone_mutation_data.csv: {len(clone_df)} clones")

print("\n✅ Ready to continue!")
print(f"\n📁 Project folder: {project_folder}")
print("📁 Subfolders:")
print(f"   - Data: {data_folder}")
print(f"   - Figures: {figures_folder}")
print(f"   - Scripts: {scripts_folder}")
