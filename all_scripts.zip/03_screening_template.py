# ============================================
# SCREENING TEMPLATE GENERATOR
# ============================================
# This script creates a screening template with 6 criteria

import pandas as pd

# Load your dark matter papers
dark_df = pd.read_excel('dark_matter_28_papers_screening.xlsx')

# Add screening columns
dark_df['Full_Text_Retrieved'] = ''
dark_df['1_Original_Research'] = ''
dark_df['2_P_aeruginosa'] = ''
dark_df['3_Cefiderocol'] = ''
dark_df['4_Resistance_Data'] = ''
dark_df['5_WGS_Data'] = ''
dark_df['6_Iron_Genes'] = ''
dark_df['INCLUDE'] = ''
dark_df['Exclusion_Reason'] = ''

dark_df.to_excel('screening_template.xlsx', index=False)
print("Screening template created!")
