# Clone-specific mutation analysis
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

# Clone mutation data
clone_data = {...}
df = pd.DataFrame(clone_data)
# Generate heatmap and bar chart
# ... (full code from your analysis)