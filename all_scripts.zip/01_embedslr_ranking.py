# EmbedSLR ranking script
!pip install git+https://github.com/s-matysik/EmbedSLR.git
from embedslr.colab_app import run
run()