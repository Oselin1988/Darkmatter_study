# STRING enrichment analysis
import requests
import pandas as pd

# Your 36 dark matter genes with STRING IDs
string_ids = [...]
# Query STRING API
# ... (full code from your analysis)