# Identify dark matter papers
import pandas as pd
dark_keywords = ['piuC', 'fptA', 'pirR', 'piuA', 'piuE', 'pvdS', 'pvdE', 'fpvA', 'tonB', 'cirA', 'pchR', 'chtA', 'siderophore']
def check_dark_matter(text):
    if pd.isna(text): return False
    return any(kw in str(text).lower() for kw in dark_keywords)
df = pd.read_excel('top_50_papers.xlsx')
df['is_dark_matter'] = df['Abstract'].apply(check_dark_matter)
dark_df = df[df['is_dark_matter'] == True]
dark_df.to_excel('dark_matter_papers.xlsx', index=False)