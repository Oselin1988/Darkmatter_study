# Create PRISMA flow diagram
import matplotlib.pyplot as plt
# ... (your prisma code)